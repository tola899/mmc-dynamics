#Nonequilibrium phase transitions in a 2D ferromagnetic spins with effective interactions
## data
All data that support the findings of this study are included within the article (and any supplementary files [39](JphysA-120659.R1) or [URL](https://github.com/tola899/mmc-dynamics)

## List of data dir
F1:	Figure 1, a plot using matplotlib
F2:	Figure 2, plots of Mean Field theory
F3:	Raw data for Figure 3 
Fs4to7:	Raw data for Figures 4 to 7 (4,5,6,7)


