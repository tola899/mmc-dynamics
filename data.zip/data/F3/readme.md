#Nonequilibrium phase transitions in a 2D ferromagnetic spins with effective interactions
## data
All data that support the findings of this study are included within the article (and any supplementary files [39](JphysA-120659.R1) or [URL](https://github.com/tola899/mmc-dynamics)

L = 80
## List of data subdir for F3
figure_3B13 = Raw dat for Figure 3  using modified Metropolis update rule
figure_3B14 = Raw dat for Figure 3  using modified Glauber update rule 


## List of data subdir for F3_Metropolis
hp:	data for h={+0.+1,+0.3,+0.5,+0.7,+0.9}
hm:	data for h={-0.1,-0.3,-0.5,-0.7,-0.9}
h0:	data for h = 0  (known)

##Headers:
0	1	2	3	4	5	6	7	8	9	10	11
T	beta	m	merr	X	Xerr	E	Eerr	C	Cerr	u4	u4err


## List of data subdir for F3_Glauber
hp:	data for h={+0.+2,+0.4,+0.6,+0.8,+1.0}
hm:	data for h={-0.2,-0.4,-0.6,-0.8,-1.0}
h0:	data for h = 0  (known)






