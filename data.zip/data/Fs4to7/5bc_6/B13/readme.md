#Data subdir

hp	h = +0.25
hm	h = -0.25

## Files in each subdirs:
L30	L = 30
L40	L = 40
L60	L = 60
L80	L = 80
L120	L = 120

##Headers:
0	1	2	3	4	5	6	7	8	9	10	11
T	beta	m	merr	X	Xerr	E	Eerr	C	Cerr	u4	u4err





